package com.example;

import java.io.IOException;
import javafx.fxml.FXML;
import javafx.scene.control.Label;

public class ProductController {
    @FXML
    private Label ProductName;
    
    @FXML
    private void switchToSearch() throws IOException {
        App.setRoot("search");
        SearchController test = new SearchController();
        
    }
    @FXML
    private void switchToCart() throws IOException {
        App.setRoot("cart");
    }
    @FXML
    private void switchToHome() throws IOException {
        App.setRoot("home");
    }
    @FXML
    private void switchToAccount() throws IOException {
        App.setRoot("account");
    }

    @FXML
    public void setLabel() throws IOException{
        //method in testing
    }
}