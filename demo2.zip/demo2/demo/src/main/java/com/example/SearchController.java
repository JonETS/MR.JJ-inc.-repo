package com.example;

import java.io.IOException;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
public class SearchController {

    @FXML
    private Button AccountButton;

    @FXML
    private Button CartButton;

    @FXML
    private Button HomeButton;

    @FXML
    private Button ProductButton;

    @FXML
    private Button ProductButton1;

    @FXML
    private TextField SearchBar;

    @FXML
    private Button SearchButton;

    @FXML
    private Label SearchLabel;

    @FXML
    private Label ProductNameLabel;

    @FXML
    private Label ProductPriceLabel;

    @FXML
    private Label ProductStockLabel;

    @FXML
    private void switchToHome() throws IOException {
        App.setRoot("home");
    }
    @FXML
    private void switchToCart() throws IOException {
        App.setRoot("cart");
    }
    @FXML
    private void switchToAccount() throws IOException {
        App.setRoot("account");
    }
    @FXML
    private void switchToProduct() throws IOException {
        App.setRoot("product");
    }
    @FXML
    private void search() throws IOException{
        
        String text = SearchBar.getText();
        SearchLabel.setText(text);
        //wip
}
